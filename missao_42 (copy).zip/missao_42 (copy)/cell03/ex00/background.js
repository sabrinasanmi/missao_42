document.addEventListener('DOMContentLoaded', function() {                                              //aguarda html carregar
    const button = document.getElementById('Botao');

    button.addEventListener('click', function() {
                const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);       // Gerar cores aleatórias em formato hexadecimal
                                        // math.random gera n. decimal e math.floor arredonda para baixo
        
        document.body.style.backgroundColor = randomColor; //alterar cor da pagina
    });
});
